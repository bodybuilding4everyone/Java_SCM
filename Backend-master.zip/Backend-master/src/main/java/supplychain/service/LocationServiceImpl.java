package supplychain.service;

//@Service("locationService")
public class LocationServiceImpl {

//	@Autowired
//	private LocationRepository locRepos;
//	@Override
//	public void save(Location e) {
//		// TODO Auto-generated method stub
//		locRepos.save(e);
//	}
//
//	@Override
//	public void delete(Long id) {
//		// TODO Auto-generated method stub
//		locRepos.delete(id);
//	}
//
//	@Override
//	public Location findOne(Long id) {
//		// TODO Auto-generated method stub
//		return locRepos.findOne(id);
//	}
//
//	@Override
//	public void flush() {
//		// TODO Auto-generated method stub
//		locRepos.flush();
//	}
//
//	@Override
//	public <S extends Location> S saveAndFlush(S e) {
//		// TODO Auto-generated method stub
//		return locRepos.saveAndFlush(e);
//	}
//
//	@Override
//	public List<Location> findAll() {
//		// TODO Auto-generated method stub
//		return locRepos.findAll();
//	}
//
//	@Override
//	public void delete(Location entity) {
//		// TODO Auto-generated method stub
//		locRepos.delete(entity);
//	}

}
