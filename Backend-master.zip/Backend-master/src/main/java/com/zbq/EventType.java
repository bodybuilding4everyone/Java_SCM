package com.zbq;

public enum EventType {
	W_START, W_UPDATE, W_ARRIVAL ,
	V_START , W_PLAN, W_RUN,W_Coord,
	MSC_MeetWeightCond , 
	V_AnchorStart , V_Dock
}
